<title><?php echo $page_title; ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="SLiMS (Senayan Library Management System) is an open source Library Management System. It is build on Open source technology like PHP and MySQL">
    <meta name="keywords" content="senayan,slims,library automation,free library application, library, perpustakaan, aplikasi perpustakaan">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="robots" content="index, nofollow">
    <link href="<?php echo SWB; ?>template/yoga/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo SWB; ?>template/yoga/css/font-awesome.min.css" rel="stylesheet">
   
    <link href="<?php echo SWB; ?>template/yoga/css/animate.css" rel="stylesheet">
    <link href="<?php echo SWB; ?>template/yoga/css/main.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="<?php echo SWB; ?>template/yoga/img/ico/favicon.ico">
    <!-- added magnifier js -->
<link type="text/css" rel="stylesheet"  href="<?php echo JWB; ?>magnifier/magnifier.css"/>
<script type="text/javascript" src="<?php echo JWB; ?>magnifier/Event.js"></script>
<script type="text/javascript" src="<?php echo JWB; ?>magnifier/magnifier.js"></script>
<script type="text/javascript" src="<?php echo JWB; ?>drift/drift.js"></script>


<script type="text/javascript" src="<?php echo $sysconf['template']['dir']; ?>/yoga/js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="<?php echo $sysconf['template']['dir']; ?>/yoga/js/jquery.flexisel.js"></script>
<script src="<?php echo $sysconf['template']['dir']; ?>/yoga/js/jquery-2.1.1.min.js"></script>


