<?php
// Information
$theme['info']['origin'] = '<a target="blank" href="https://github.com/VinceG/Bootstrap-Admin-Theme-3">Bootstrap Admin Theme-3</a>';
$theme['info']['author'] = '';
$theme['info']['modified'] = '<a target="blank" href="https://fb.com/erwan.setyobudi">Erwan Setyo Budi</a>';
$theme['info']['version'] = '1.0.0';
$theme['info']['description'] = 'Flat Theme FOr Setiadi 2';
?>